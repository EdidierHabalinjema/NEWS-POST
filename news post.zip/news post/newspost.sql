-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2021 at 04:09 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blogpost`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `comment_by` int(11) NOT NULL,
  `comment_title` varchar(150) NOT NULL,
  `comment_details` text NOT NULL,
  `comment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `login_id`, `date`) VALUES
(1, 1, '2021-02-23 13:28:15'),
(2, 1, '2021-02-23 13:28:15'),
(3, 2, '2021-02-23 13:31:21'),
(4, 1, '2021-02-23 13:33:12'),
(5, 1, '2021-02-23 13:33:12'),
(6, 1, '2021-02-23 14:19:07'),
(7, 1, '2021-02-23 14:19:07');

-- --------------------------------------------------------

--
-- Table structure for table `posters`
--

CREATE TABLE `posters` (
  `id` int(11) NOT NULL,
  `post_by` int(11) NOT NULL,
  `post_title` varchar(25) NOT NULL,
  `post_details` text NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posters`
--

INSERT INTO `posters` (`id`, `post_by`, `post_title`, `post_details`, `post_date`) VALUES
(1, 1, 'COLLEGE COMPOSITION 2', '				Hi everyone, welcome to our session on Finding your Purpose. Daniel, from the\r\nprevious session exposed you to understanding the complexity of solving any social problem\r\nand how when we try to solve something, it\'s actually not as easy as it seems. This session is\r\nabout how we can discover our unique purpose and to work in a social problem. So, without any\r\nfurther ado, let\'s get right into it. What we\'re gonna be covering today is pretty simple. We\'re\r\ngonna be answering this age-old question that everyone wants to know: â€œwhat is purposeâ€, and,\r\nmore importantly, â€œwhat is my life\'s purposeâ€. I 			', '2021-02-23 14:08:13'),
(2, 1, 'Lesson Transcript', '				Four years ago, I was just feeling really upset, going through a routine, but at the\r\nend of the day I was not feeling happy, I was not feeling satisfied. I could wake up and still feel\r\ntired and miserable. I wasn\'t really finding my passion and at the same time I had friends who\r\nwere genuinely excited with their lives. I was feeling kind of jealous and I questioned why I\r\ncouldnâ€™t get what they had. I think it\'s kind of like a puzzle where you\'ve found every single\r\nexcept for one piece. Something is missing. Now I\'ll be talking you through about how I found\r\nmy purpose, and Iâ€™ll be dropping truth bombs here and then. First truth: no one finds the\r\npurpose immediately		', '2021-02-23 14:15:35'),
(3, 1, 'Lesson Transcript', '				Four years ago, I was just feeling really upset, going through a routine, but at the\r\nend of the day I was not feeling happy, I was not feeling satisfied. I could wake up and still feel\r\ntired and miserable. I wasn\'t really finding my passion and at the same time I had friends who\r\nwere genuinely excited with their lives. I was feeling kind of jealous and I questioned why I\r\ncouldnâ€™t get what they had. I think it\'s kind of like a puzzle where you\'ve found every single\r\nexcept for one piece. Something is missing. Now I\'ll be talking you through about how I found\r\nmy purpose, and Iâ€™ll be dropping truth bombs here and then. First truth: no one finds the\r\npurpose immediately		', '2021-02-23 14:16:46'),
(4, 1, 'COLLEGE COMPOSITION 3', '		Hollywood movies kind of shows us all the time that it seems like people\r\nwake up and go â€œI\'m gonna be super heroâ€ or â€œI\'m gonna go to Africa to work as an aid workerâ€\r\nor â€œI\'m just going to do the best that I can beâ€ and so on. But purpose doesn\'t hit you lightly in\r\nface. The truth is we need to be prepared to work for it. Purpose is a journey and that\'s what\r\neveryone needs to know. This journey can take months.\r\n					', '2021-02-23 14:19:42');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `fullname` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `fullname`, `email`, `password`) VALUES
(1, 'bondo dieubonne', 'dieudo@gmail.com', '123123'),
(2, 'david mukalayi', 'david@gmail.com', '321321');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posters`
--
ALTER TABLE `posters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `posters`
--
ALTER TABLE `posters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
