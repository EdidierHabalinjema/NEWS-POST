<?php
    session_start();
	include('pdo.php');

	if(isset($_POST['submit'])){

		$post_title = $_POST['post-title'];
		$post_details= $_POST['post-area'];
		//function for posters
		adminPost($_SESSION['id'],$post_title,$post_details);
	}
 function adminPost($sess_id,$title,$postdetails){
	 global $pdo;
	 $insert_post = 'insert into posters(post_by,post_title,post_details,date)
					values(:postby,:posttitle,:postdetails,NOW())';

					$stmt = $pdo->prepare($insert_post);

					$stmt->bindvalue(':postby',$sess_id);
					$stmt->bindvalue(':posttitle',$title);
					$stmt->bindvalue(':postdetails',$postdetails);
				    $stmt->execute();
 }
 function eghjk(){
	include('pdo.php');
$select='SELECT * FROM register';
$stmt=$pdo->query($select);
while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
$count=count($row['id']);
	echo $count;
 }
 }
 function count_user($id){
	global $pdo;
	$select = 'select count(poster_id) as nbr_comment
	from liketable where poster_id='.$id.'';
		$stmt= $pdo->query($select);
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			 echo $row['nbr_comment'];
		}
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>admin</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alef">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/Highlight-Clean.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Search.css">
    <link rel="stylesheet" href="assets/css/Testimonials.css">
</head>

<body>

            <?php include('nav.php');?><br><br>

		<div class="container">
        <div class="col">
            <h1 class="text-center" style="margin-top: 45px;">Only admin  can view this page</h1>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div>
                    <h1 class="text-center">There are<span class="text-primary" style="margin-left: 30px;"><?php user_count();?>  </span> members

					</h1>
                </div>
                <ul class="list-group">
                    <li class="list-group-item"><span><?php include('usersnames.php');?></span></li>

                </ul>
            </div>
            <div class="col">
			<?php
			//function to count number of users in database
   function user_count(){
	global $pdo;
	$select = 'select count(id) as nbr_comment
	from register where id!='.$_SESSION['id'].'';
		$stmt= $pdo->query($select);
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			 echo $row['nbr_comment'];
		}
}?>

<?php
	//function to count number of posters
	function post_count(){
	global $pdo;
	$select = 'select count(id) as post_count
	from posters where id=id';
		$stmt= $pdo->query($select);
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			 echo $row['post_count'];
		}
}?>
                <h1 class="text-center">There is <?php post_count();?> posters </h1>
                <p class="text-center" style="margin-top: 45px;">Admin have all capability to add a new post and delete or update if possible</p>
				<?php
				   include("pdo.php");
						$select = "select * from posters";
						$stmt= $pdo->query($select);
						while($row = $stmt->fetch(PDO::FETCH_ASSOC)):
              $poster_id=$row['id'];

              if(isset($_POST["delete_post"]) && isset($_POST["hidden_input"])){
              $delete_posts="DELETE FROM posters WHERE id='".$_POST['hidden_input']."'";
              $delete=$pdo->query($delete_posts);
              if($delete){
                header('location:pageadmin.php');
              }
              else {
              echo "not deleted";              }
              ?>
              <script>
              function delete_posts(){
                return confirm("do you want to delete this post?");
              }
              </script>
              <?php
              }
						?>

                <div class="row" style="margin-bottom:15px;">
                    <div class="intro" style="background-color: #66d7d7;">
					<span style = "float:right; color:white;"><?php echo $row['date'];?></span>
                <p><h2 class="text-center" style="opacity: 1;"><?php echo $row['post_title'];?></h2>
				</p>

<p class="text-center" style="color: #1f1d1d;"><?php
echo $row['post_details'];
echo '<form action="#" method="post">
<input type="hidden" name="hidden_input" onclick="return delete_posts()" value="'.$row["id"].'">
<input type="submit" value="Delete Post" onclick="return delete_posts()" name="delete_post">

</form>';?></p>
            </div>
                </div>
				<?php endwhile;?>
                <div>
                    <form method="post" class="mr-auto" action="#">
					<input class="form-control" type="text" style="margin-top: 15px;margin-bottom: 8px;" name="post-title" placeholder="write the title of your post">
					<textarea class="form-control d-lg-flex align-items-lg-end" name="post-area" placeholder="put your post"
                            rows="3" wrap="soft" required=""></textarea>
					<button class="btn btn-primary text-right d-flex d-lg-flex m-auto justify-content-lg-start" type="submit"
					name="submit" style="margin-top: 15px;background-color: #66d7d7;">send post</button></form>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
</body>

</html>
