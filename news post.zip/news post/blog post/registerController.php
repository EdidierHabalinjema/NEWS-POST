<?php
include('pdo.php');
   if(isset($_POST['submit'])){
	   $fullname = $_POST['fullname'];
	   $email = $_POST['email'];
	   $password = $_POST['password'];
	   
	   $insert= 'insert into register(fullname,email,password) 
	   values(:fullname,:email,:password)';
	   $stmt = $pdo->prepare($insert);
	   
		   $stmt->bindvalue(':fullname',$fullname);
		   $stmt-> bindvalue(':email',$email);
		   $stmt->bindvalue(':password',$password);
		   //$stmt->bindvalue(':date', NOW());
		   
				$stmt->execute();
				if($stmt){
					header('location:login.php');
					//echo'inserted';
				}
				else{
					echo"error";
				}
	   
	   
   }


?>