<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Untitled</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css?h=3f357f95326301379fa2c96a673e76ab">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i">
    <link rel="stylesheet" href="assets/css/Registration-Form-with-Photo.css?h=767a83533e5778c3fc1bef9f6c8da61d">
</head>

<body>
    <div class="register-photo">
        <div class="form-container">
            <div class="image-holder"></div>
            <form method="post" action="registerController.php">
                <h2 class="text-center"><strong>Create</strong> an account.</h2>
                <div class="form-group"><input class="border rounded form-control" type="text" name="fullname" placeholder="full name" required=""></div>
                <div class="form-group"><input class="border rounded form-control" type="email" name="email" placeholder="email" required=""></div>
                <div class="form-group"><input class="border rounded form-control" type="password" placeholder="Password " name="password" required=""></div>
                <div class="form-group">
                    <div class="form-check"><label class="form-check-label">
					<input class="form-check-input" type="checkbox" required="">I agree to the license terms.</label></div>
                </div>
                <div class="form-group"><button class="btn btn-primary btn-block" type="submit" name="submit">Sign Up</button></div>
				<a class="already" href="login.php">You already have an account? Login here.</a></form>
        </div>
    </div>
    <script src="assets/js/jquery.min.js?h=83e266cb1712b47c265f77a8f9e18451"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js?h=7c038681746a729e2fff9520a575e78c"></script>
</body>

</html>