$(document).ready(function(){
	$('[data-bs-tooltip]').tooltip();
});