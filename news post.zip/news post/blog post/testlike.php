<?php
if(isset($_POST['like']) and isset($_POST['likehidden'])){
	  echo $_POST['likehidden'];
	  
  }
?>