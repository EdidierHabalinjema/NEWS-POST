<nav class="navbar navbar-dark navbar-expand-lg fixed-top bg-dark navbar-custom">
        <div class="container"><a class="navbar-brand" href="index.php">NEWS POST</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navbarResponsive"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
			<?php
			
			if(!isset($_SESSION['id'])){
				echo'
			
                <ul class="nav navbar-nav ml-auto">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="register.php">Sign Up</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="login.php">Log In</a></li>
                </ul>
				';
			}
			if(isset($_SESSION['id'])){
				echo'
			
                <ul class="nav navbar-nav ml-auto">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="">Welcome '.$_SESSION['fullname'].'</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="logout.php">LOG OUT</a></li>
                </ul>
				';
			}
			
			?>
            </div>
        </div>
    </nav>