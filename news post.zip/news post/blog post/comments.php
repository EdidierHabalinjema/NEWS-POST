<?php
session_start();
 include('pdo.php');
 $err_message='';
 $comment_id =$_GET['postid'];
 
 if(isset($_POST['sendComment'])){
	 
	if($_SESSION['id']){
		$comment = $_POST['text-comment'];
		$insert = 'insert into comments(comment_id,comment_by,comment_details,date)
		values(:comment_id,:comment_by,:comment_details,CURTIME())';
			$stmt = $pdo->prepare($insert);
			$stmt->bindvalue(':comment_id',$comment_id);
			$stmt->bindvalue(':comment_by',$_SESSION['id']);
			$stmt->bindvalue(':comment_details',$comment);
			$stmt->execute();
		
	}
	else{
		$err_message.='you must<a href="login.php"> login</a> or <a href="register.php">create account</a>';
	}
}
//count comments
function count_comments(){
	global $pdo;
	$select = 'select count(comment_id) as nbr_comment from comments where comment_id='.$_GET['postid'].'';
		$stmt= $pdo->query($select);
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			 echo $row['nbr_comment'];
		}
}
	
	
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>comments</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alef">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/Highlight-Clean.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Search.css">
    <link rel="stylesheet" href="assets/css/Testimonials.css">
</head>

<body>
    <section></section>
    <nav class="navbar navbar-light navbar-expand-md navigation-clean-search">
        <div class="container"><a class="navbar-brand" href="#">NEWS POST</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse"
                id="navcol-1">
                
                <form class="form-inline mr-auto" target="_self">
                </form><a class="btn btn-light action-button" role="button" href="logout.php">log out</a></div>
        </div>
    </nav>
    <h2 class="text-center" style="background-color: #66d7d7;">comments on post<span class="text-right text-primary"><?php count_comments();?></span></h2>
    <div class="container">
        <div class="row">
            <div class="col">
                <section></section>
            </div>
        </div>
    </div>
	<div class="container">
        <div class="row">
		
		<div class="col-lg-4">
		<?php 
		//select all details from posters table
			$stmt = $pdo->query('select post_title,post_details, date from posters 
			where id='.$_GET['postid'].'');
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		?>
		<div class="intro" style="background-color: #66d7d7;">
		<span style="color:white;float:right;">
			<?php echo $row['date'];?></span>
               <h2 class="text-center" style="opacity: 1;">
				 <?php echo $row['post_title'];?></h2>
                    <p class="text-center" style="color: #1f1d1d;">
				       <?php echo $row['post_details'];?>&nbsp;&nbsp;</p>
            </div>
		</div>
            <div class="col-lg-7">
    <div class="highlight-clean">
        <div class="container-md text-center">
		<?php 
		$select = 'select * from comments where comment_id='.$_GET['postid'].'';
		$stmt= $pdo->query($select);
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)):
		
		?>
            <div class="intro" style="background-color: #66d7d7;">
                <p class="text-center" style="color: #1f1d1d;">
				<span style="float:right; color:white;"><?php echo $row['date'];?></span>&nbsp;&nbsp;</br>
				<?php echo $row['comment_details'];?>&nbsp;&nbsp;</p>
            </div>
			<?php endwhile;?>
            <div data-toggle="tooltip" data-bs-tooltip="" data-placement="bottom" class="buttons" title="this must still on bottom">
                <form method="post" action="#">
				<legend><span style="color:red;"><?php echo $err_message;?></span></legend>
				<textarea class="form-control form-control-sm" name="text-comment"
				placeholder="leave your comment" rows="4" cols="5" required=""></textarea>
				<button type="submit" class="btn btn-primary"  name="sendComment"  style="background-color: #56c6c6;">send comment</button>
				</form></div>
        </div>
    </div>
	</div>
	</div>
	</div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
</body>

</html>