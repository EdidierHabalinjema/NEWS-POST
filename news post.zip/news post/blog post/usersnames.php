<?php

include('pdo.php');
$select='SELECT*FROM register WHERE id!='.$_SESSION["id"].'';
$stmt=$pdo->query($select);
while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
	$user_id=$row['id'];
	echo '
	<form action="#" method="post">
	<li class="list-group-item"><span>'.$row['fullname'].'<input type="submit" name="delete" onclick="return confirm_delete()" style="border:none;border-radius:10px;color:#fff; background:#f25;float:right;" value="Delete user"</span></li>
	</form>';
}

if(isset($_POST['delete'])){
	$Delete_user = "DELETE FROM register WHERE
   id='$user_id'";
	$stmt=$pdo->query($Delete_user);

}


?>
<script type='text/javascript'>
function confirm_delete()
{
   return confirm("Are you sure you want to delete this user?");
}
</script>
