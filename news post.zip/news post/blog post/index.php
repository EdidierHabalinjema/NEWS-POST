<?php
 session_start();
   include('pdo.php');
	$err_message='';
	
  // register like
if(isset($_POST['like']) && isset($_POST['likehidden'])){

    if($_POST['hidden_like']==$_SESSION['id']){
    	   $likehidden =(int) $_POST['likehidden'];
    	   $insert = 'insert into liketable(like_by,poster_id,date)
    	   values(:likeby,:poster_id,NOW())';
    	   $stmt = $pdo->prepare($insert);
    	   $stmt->bindvalue(':likeby',$_SESSION['id']);
    	   $stmt->bindvalue(':poster_id',$_POST['likehidden']);
    	   $stmt->execute();
            echo "you have liked this post";
       }
       else{
    	 $err_message.='you must<a href="login.php"> login</a> or <a href="register.php">create account</a>';
       }

       //register unlike

       if(isset($_POST['unlike']) && isset($_POST['unlikehidden'])){
    
		   if($_POST['unlike']==$_SESSION['id']){
			   
    	   $unlikehidden =(int) $_POST['unlikehidden'];
    	   $insert = 'insert into unliketable(unlike_by,poster_id,date)
    	   values(:unlikeby,:poster_id,NOW())';
    	   $stmt = $pdo->prepare($insert);
    	   $stmt->bindvalue(':unlikeby',$_SESSION['id']);
    	   $stmt->bindvalue(':poster_id',$_POST['unlikehidden']);
    	   $stmt->execute();
		   }
       }
       else{
    	 $err_message.='you must<a href="login.php"> login</a> or <a href="register.php">create account</a>';
       }
       
  }
   //count number of comments on each post
   function count_comments($id){
	global $pdo;
	$select = 'select count(comment_id) as nbr_comment
	from comments where comment_id='.$id.'';
		$stmt= $pdo->query($select);
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			 echo $row['nbr_comment'];
		}
}
 //function to count number of likes on each post
   function count_like($id){
	global $pdo;
	$select = 'select count(poster_id) as nbr_comment
	from liketable where poster_id='.$id.'';
		$stmt= $pdo->query($select);
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			 echo $row['nbr_comment'];
		}
}
//function to count number of unlikes on each post
   function count_unlike($id){
	global $pdo;
	$select = 'select count(poster_id) as nbr_comment
	from unliketable where poster_id='.$id.'';
		$stmt= $pdo->query($select);
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			 echo $row['nbr_comment'];
		}
}


?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>news post</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css?h=3f357f95326301379fa2c96a673e76ab">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i">
</head>

<body>
    <?php include('nav.php');?>
    <header class="masthead text-center text-white"style="background:url('home1.png');hight:auto;width:auto;float:top;  -webkit-background-size:cover;">
        <div class="masthead-content">
            <div class="container">
                <h1 class="masthead-heading mb-0">NEWS POST</h1>
                <h4 class="display-1 masthead-subheading mb-0">scroll down to view all new posters</h4>
                <p>for you to comment, like and unlike a poster you must have an account</p>
				<?php
				if(!isset($_SESSION['id'])){
					echo'
				<a class="btn btn-primary btn-xl rounded-pill mt-5" role="button" href="login.php" style="background-color: rgb(14,12,13);">logIn</a><a class="btn btn-primary btn-xl rounded-pill mt-5"
                    role="button" href="register.php" style="background-color: rgb(13,11,12);">sign up</a>
					';
				}
					?>
					</div>
        </div>
        <div class="bg-circle-1 bg-circle"></div>
        <div class="bg-circle-2 bg-circle"></div>
        <div class="bg-circle-3 bg-circle"></div>
        <div class="bg-circle-4 bg-circle"></div>
    </header>
	<section style="">
	<div class="container" >
	<?php
	include("pdo.php");
	/*select all posters for users by joinning two tables
	(posters table and register table)*/

	$select ="SELECT register.id,register.fullname,
	posters.id,posters.post_by, posters.post_title,posters.post_details, posters.date
	FROM register JOIN posters
	ON register.id = posters.post_by";
	$stmt =$pdo->query($select);
	while($row = $stmt->fetch(PDO::FETCH_ASSOC)):
	?>
            <div class="row align-items-center"style="margin-bottom:10px;background-color: #66d7d7;">
                <div class="col-lg-10 order-lg-2 offset-2">
                    <div class="p-5 align-items-center">
                        <p>posted by<span style="margin-left: 15px;"><?php echo $row['fullname'];?></span>
						<span style="margin-left: 25px;background-color: #ffffff;color: rgb(41,37,33);"><?php echo $row['date'];?></span></p>
                        <h3 class="display-5"><?php echo $row['post_title'];?></h3>
                        <p><?php echo $row['post_details'];?></p>

						<!-- display error message if user want to like, unlike a poster
						while he/she did not have an account or login-->
						<p><span style="color:red"><?php echo $err_message;?></span></p>
						<table><tr>

							<td><form method="post" action="comments.php?postid=<?php echo $row['id'];?>">
							<legend class="text-white"><?php count_comments($row['id'])?></legend>
							<input type="hidden" name="comment">
							<button class="btn btn-primary" type="submit"
							style="background-color: rgb(9,183,238);margin: 0px 15px;" name="comment">comment</button></form></td>


							<td><form method="post" action="#">
							<legend class="text-white"><?php count_like($row['id'])?></legend>
							<input type="hidden" name="likehidden" value='<?php echo $row['id'];?>'>
							
							<input type="hidden" value="<?php echo $row_like["like_by"];?> " name="hidden_like">
							<button class="btn btn-primary" type="submit" name="like" style="background-color: rgb(9,238,128);margin: 0px 15px;">&nbsp; &nbsp; &nbsp; like&nbsp; &nbsp;</button></form></td>


							<td><form method="post" action="#">
							<legend class="text-white"><?php count_unlike($row['id'])?></legend>
							<input type="hidden" name="unlikehidden" value='<?php echo $row['id'];?>'>
							<button class="btn btn-primary" type="submit"
							name="unlike" style="background-color: rgb(238,160,9);margin: 0px 15px;">&nbsp; &nbsp;unlike&nbsp;&nbsp;</button></form></td>
						</tr></table>
					</div>
                </div>
            </div><?php endwhile;?>
        </div>
    </section>


    <footer class="py-5 bg-black">
        <div class="container">
            <p class="text-center text-white m-0 small">Copyright&nbsp;© takenoLAB 2021</p>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js?h=83e266cb1712b47c265f77a8f9e18451"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js?h=7c038681746a729e2fff9520a575e78c"></script>
</body>

</html>
