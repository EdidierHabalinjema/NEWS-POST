<?php
	include('pdo.php');
	session_start();

	if(isset($_POST['submit'])){

		$email = $_POST['email'];
		$password = $_POST['password'];

		$select = 'select * from register where email=:email and password=:password';
		$stmt = $pdo->prepare($select);
		$stmt->execute(array(
		':email'=>$email, ':password'=>$password));

		$row = $stmt->fetch(PDO::FETCH_ASSOC);

		if($row['email']==$email&&$row['password']==$password){
			if($row['id']!==1){
				$_SESSION['fullname']= $row['fullname'];
				$_SESSION['id']= $row['id'];
			//save all user login
			login_session($row['id']);
			header('location:index.php');

			}
			if($row['id']==1){
				$_SESSION['fullname']= $row['fullname'];
				$_SESSION['id']= $row['id'];
				//save all user login
				login_session($row['id']);
				header('location:pageadmin.php');

			}
		}
		else{
			echo"Your information is incorrect";
			header('refresh:1,login.php');
		}

	}
	function login_session($id){

		global $pdo;
		$insert = 'insert into logindetails(login_id,date)
		value(:login_id,Now())';
		$stmt = $pdo->prepare($insert);
		$stmt->bindvalue(':login_id',$id);
		//$stmt->bindvalue(':date',Now());
		$stmt->execute();
	}

?>
