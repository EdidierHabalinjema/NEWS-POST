<?php

	
	try{
		$pdo = new PDO('mysql:host=localhost;dbname=blogpostesite','root','');
		$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
		if($pdo){
			//echo"connect";
		}
	}
	catch(PDOException $e){
		echo $e->getMessage();
	}

?>